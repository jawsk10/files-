DRIVER_INITIALIZE DriverEntry;
DRIVER_UNLOAD DriverUnload;


NTSTATUS
DriverEntry(
    __in PDRIVER_OBJECT DriverObject,
    __in PUNICODE_STRING RegistryPath
    );

VOID
DriverUnload(
    __in PDRIVER_OBJECT DriverObject
    );

VOID
RaiseErrorMessage(
    __in int Index
    );

PEPROCESS
GetCsrssProcess();

PVOID
LookupModuleBaseByPointer(
    __in PVOID AddressWithinImage
    );

__forceinline
PVOID
GetAddressCursorAcceleration(
    __in PVOID ImageBase
    );

VOID
FASTCALL
FindUniqueBytePattern(
    __inout PVOID *Address,
    __in PUCHAR Start,
    __in PUCHAR End,
    __in PUCHAR Pattern,
    __in SIZE_T Size,
    __in_opt SIZE_T Offset
    );

BOOLEAN
PatchCursorAcceleration(
    __in PUCHAR Address
    );