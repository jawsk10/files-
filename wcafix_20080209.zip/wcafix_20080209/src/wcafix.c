#include <ntifs.h>
#include <ntimage.h>
#include "wcafix.h"
#include "undoc.h"

#ifdef ALLOC_PRAGMA
  #pragma alloc_text("INIT", DriverEntry)
  #pragma alloc_text("INIT", RaiseErrorMessage)
  #pragma alloc_text("INIT", GetCsrssProcess)
  #pragma alloc_text("INIT", LookupModuleBaseByPointer)
  #pragma alloc_text("INIT", GetAddressCursorAcceleration)
  #pragma alloc_text("INIT", FindUniqueBytePattern)
  #pragma alloc_text("INIT", PatchCursorAcceleration)
  #pragma alloc_text("PAGE", DriverUnload)
#endif

#ifdef ALLOC_DATA_PRAGMA
  #pragma data_seg("INITD")
#endif
#ifdef _M_IX86
  UCHAR PatternCursorAcceleration1[] = {0x83,0x3D,0xAD,0xAD,0xAD,0xAD,0x00,0x57,0x53,0xAD,
                                        0xAD,0xFF,0x75,0x08,0xE8,0xAD,0xAD,0xAD,0xAD,0xFF,
                                        0x75,0x0C,0x89,0x45,0x08,0xE8};
  UCHAR PatternCursorAcceleration2[] = {0x39,0x1D,0xAD,0xAD,0xAD,0xAD,0x57,0x0F,0xAD,0xAD,
                                        0xAD,0xAD,0xAD,0x8D,0x45,0x0C,0x50,0x8D,0x45,0x08,
                                        0x50,0xE8};
  UCHAR PatternCursorAcceleration3[] = {0x39,0x1D,0xAD,0xAD,0xAD,0xAD,0x57,0x0F,0xAD,0xAD,
                                        0xAD,0xAD,0xAD,0xFF,0x75,0x20,0x8D,0x45,0x0C,0x50,
                                        0x8D,0x45,0x08,0x50,0xE8};
  UCHAR PatternCursorAcceleration4[] = {0x83,0x3D,0xAD,0xAD,0xAD,0xAD,0x00,0x53,0x57,0xAD,
                                        0xAD,0xFF,0x75,0x20,0x8D,0x45,0x0C,0x50,0x8D,0x45,
                                        0x08,0x50,0xE8};
#endif

#ifdef _M_X64
  UCHAR PatternCursorAcceleration1[] = {0x83,0x3D,0xAD,0xAD,0xAD,0xAD,0x00,0x0F,0xAD,0xAD,
                                        0xAD,0xAD,0xAD,0x44,0x8B,0x44,0x24,0x60,0x48,0x8D,
                                        0x54,0x24,0x38,0x48,0x8D,0x4C,0x24,0x30,0xE8};
  UCHAR PatternCursorAcceleration2[] = {0x83,0x3D,0xAD,0xAD,0xAD,0xAD,0x00,0xAD,0xAD,0x44,
                                        0x8B,0x44,0x24,0x60,0x48,0x8D,0x54,0x24,0x38,0x48,
                                        0x8D,0x4C,0x24,0x30,0xE8};
#endif
#ifdef ALLOC_DATA_PRAGMA
  #pragma data_seg()
#endif

NTSTATUS
DriverEntry(
    __in PDRIVER_OBJECT DriverObject,
    __in PUNICODE_STRING RegistryPath
    )
{
    NTSTATUS Status;
    KAPC_STATE ApcState;
    PEPROCESS CsrssProcess;
    PDRIVER_OBJECT Win32kDriver;
    PVOID ImageBase;
    PVOID Address;

    UNICODE_STRING Win32kName
        = RTL_CONSTANT_STRING(L"\\Driver\\Win32k");

    PAGED_CODE();

    KdPrint(("[WCAFIX] Loaded.\n"));

    // Get a referenced pointer to Win32k's driver object.
    Status = ObReferenceObjectByName(&Win32kName,
                                     OBJ_CASE_INSENSITIVE,
                                     NULL,
                                     0,
                                     *IoDriverObjectType,
                                     KernelMode,
                                     NULL,
                                     &Win32kDriver);

    if (!NT_SUCCESS(Status)) {
        KdPrint(("[WCAFIX] Could not reference Win32k's driver object!\n"));

        RaiseErrorMessage(0);
        return Status;
    }

    ImageBase = LookupModuleBaseByPointer(Win32kDriver->DriverInit);

    if (!ImageBase) {
        KdPrint(("[WCAFIX] Could not determine Win32k's base address!\n"));

        RaiseErrorMessage(0);
        Status = STATUS_UNSUCCESSFUL;
        goto End;
    }

    KdPrint(("[WCAFIX] Win32k base address: 0x%p\n", ImageBase));

    // Get a referenced pointer to CSRSS' process object.
    CsrssProcess = GetCsrssProcess();

    if (!CsrssProcess) {
        KdPrint(("[WCAFIX] Could not reference CSRSS' process object!\n"));

        RaiseErrorMessage(1);
        Status = STATUS_UNSUCCESSFUL;
        goto End;
    }

    // Attach to CSRSS' address space to provide access to its session space.
    // Win32k resides in session space to facilitate concurrent sessions.
    KeStackAttachProcess(CsrssProcess, &ApcState);

    Address = GetAddressCursorAcceleration(ImageBase);

    if (!Address) {
        KdPrint(("[WCAFIX] Could not find unique byte pattern!\n"));

        RaiseErrorMessage(2);
        Status = STATUS_UNSUCCESSFUL;
    } else {
        KdPrint(("[WCAFIX] Patch address: 0x%p\n", Address));

        // A unique location has been found, so attempt to patch.
        if (!PatchCursorAcceleration(Address)) {
            KdPrint(("[WCAFIX] Could not patch cursor acceleration!\n"));

            RaiseErrorMessage(3);
            Status = STATUS_UNSUCCESSFUL;
        }
    }

    KeUnstackDetachProcess(&ApcState);

    DriverObject->DriverUnload = DriverUnload;

    ObDereferenceObject(CsrssProcess);

  End:
    ObDereferenceObject(Win32kDriver);

    return Status;
}

VOID
RaiseErrorMessage(
    __in int Index
    )
/*++

Raise informational hard error to inform user about failure.

--*/
{
    UNICODE_STRING Message0
        = RTL_CONSTANT_STRING(L"Windows Cursor Acceleration Fix has failed to patch cursor acceleration, "
                              L"because the driver Win32k could not be accessed.");
    UNICODE_STRING Message1
        = RTL_CONSTANT_STRING(L"Windows Cursor Acceleration Fix has failed to patch cursor acceleration, "
                              L"because the process CSRSS could not be accessed.");
    UNICODE_STRING Message2
        = RTL_CONSTANT_STRING(L"Windows Cursor Acceleration Fix has failed to patch cursor acceleration, "
                              L"because a unique byte pattern could not be found.");
    UNICODE_STRING Message3
        = RTL_CONSTANT_STRING(L"Windows Cursor Acceleration Fix has failed to patch cursor acceleration, "
                              L"because write access could not be provided.");
    PUNICODE_STRING Messages[] = {&Message0, &Message1, &Message2, &Message3};

    PAGED_CODE();

    IoRaiseInformationalHardError(STATUS_FATAL_APP_EXIT, Messages[Index], NULL);
}

__forceinline
PEPROCESS
GetCsrssProcess()
/*++

Search for first CSRSS process instance
and return a referenced pointer to its EPROCESS structure.

--*/
{
    NTSTATUS Status;
    PVOID Buffer;
    ULONG BufferSize;
    ULONG ReturnLength;
    PEPROCESS Process;
    PSYSTEM_PROCESS_INFORMATION ProcessInfo;

    UNICODE_STRING ProcessName
        = RTL_CONSTANT_STRING(L"csrss.exe");

    PAGED_CODE();

    // Get process list.
    for (BufferSize = PAGE_SIZE, ReturnLength = 0;;) {
        Buffer = ExAllocatePoolWithTag(PagedPool, BufferSize, 0);

        if (!Buffer)
            return NULL;

        Status = ZwQuerySystemInformation(SystemProcessInformation,
                                          Buffer,
                                          BufferSize,
                                          &ReturnLength);

        if (Status != STATUS_INFO_LENGTH_MISMATCH)
            break;

        ExFreePool(Buffer);

        // BUG: Windows 2000 does not properly set ReturnLength!
        if (ReturnLength <= BufferSize)
            ReturnLength = BufferSize + BufferSize;

        BufferSize = ReturnLength;
    }

    Process = NULL;

    // Parse process list.
    if (NT_SUCCESS(Status)) {
        for (ProcessInfo = (PSYSTEM_PROCESS_INFORMATION)Buffer;;) {
            if (RtlEqualUnicodeString(&ProcessInfo->ImageName, &ProcessName, TRUE)) {
                Status = PsLookupProcessByProcessId(ProcessInfo->UniqueProcessId,
                                                    &Process);

                if (!NT_SUCCESS(Status))
                    Process = NULL;

                break;
            }

            if (!ProcessInfo->NextEntryOffset)
                break;

            ProcessInfo = (PSYSTEM_PROCESS_INFORMATION)((ULONG_PTR)ProcessInfo +
                                                        ProcessInfo->NextEntryOffset);
        }
    }

    ExFreePool(Buffer);

    return Process;
}

__forceinline
PVOID
LookupModuleBaseByPointer(
    __in PVOID AddressWithinImage
    )
/*++

Locate kernel module containing specified address.
Returns base address of found module,
or NULL in case of failure.

--*/
{
    NTSTATUS Status;
    PVOID Buffer;
    ULONG BufferSize;
    ULONG ReturnLength;
    PRTL_PROCESS_MODULES Modules;
    PVOID ImageBase;
    ULONG i;

    PAGED_CODE();

    // Get module list.
    for (BufferSize = PAGE_SIZE, ReturnLength = 0;;) {
        Buffer = ExAllocatePoolWithTag(PagedPool, BufferSize, 0);

        if (!Buffer)
            return NULL;

        Status = ZwQuerySystemInformation(SystemModuleInformation,
                                          Buffer,
                                          BufferSize,
                                          &ReturnLength);

        if (Status != STATUS_INFO_LENGTH_MISMATCH)
            break;

        ExFreePool(Buffer);

        if (ReturnLength <= BufferSize)
            ReturnLength = BufferSize + BufferSize;

        BufferSize = ReturnLength;
    }

    ImageBase = NULL;

    // Parse module list.
    if (NT_SUCCESS(Status)) {
        Modules = (PRTL_PROCESS_MODULES)Buffer;
        for (i = 0; i < Modules->NumberOfModules; i++) {
            if ((ULONG_PTR)AddressWithinImage <
                (ULONG_PTR)Modules->Modules[i].ImageBase)
                continue;

            if ((ULONG_PTR)AddressWithinImage >=
                ((ULONG_PTR)Modules->Modules[i].ImageBase +
                Modules->Modules[i].ImageSize))
                continue;

            ImageBase = Modules->Modules[i].ImageBase;

            break;
        }
    }

    ExFreePool(Buffer);

    return ImageBase;
}

__forceinline
PVOID
GetAddressCursorAcceleration(
    __in PVOID ImageBase
    )
{
    PIMAGE_NT_HEADERS NtHeaders;
    PIMAGE_SECTION_HEADER SectionHeader;
    PUCHAR Start, End, Address;
    ULONG i;

    PAGED_CODE();

    NtHeaders = (PIMAGE_NT_HEADERS)((ULONG_PTR)ImageBase +
                                    ((PIMAGE_DOS_HEADER)ImageBase)->e_lfanew);

    Address = NULL;

    // Parse section headers searching for code sections.
    SectionHeader = IMAGE_FIRST_SECTION(NtHeaders);
    for (i = 0; i < NtHeaders->FileHeader.NumberOfSections; i++) {
        if ((SectionHeader[i].Characteristics &
            (IMAGE_SCN_CNT_CODE | IMAGE_SCN_MEM_READ)) !=
            (IMAGE_SCN_CNT_CODE | IMAGE_SCN_MEM_READ))
            continue;

        // Do not try to access possibly discarded sections.
        if ((SectionHeader[i].Characteristics & IMAGE_SCN_MEM_DISCARDABLE) ||
            (*(PULONG)SectionHeader[i].Name == 'TINI'))
            continue;

        Start = (PUCHAR)((ULONG_PTR)ImageBase + SectionHeader[i].VirtualAddress);
        End = (PUCHAR)((ULONG_PTR)Start + SectionHeader[i].Misc.VirtualSize - 1);

        #ifdef _M_IX86
          FindUniqueBytePattern(&Address,
                                Start,
                                End,
                                PatternCursorAcceleration1,
                                sizeof(PatternCursorAcceleration1),
                                9);
          FindUniqueBytePattern(&Address,
                                Start,
                                End,
                                PatternCursorAcceleration2,
                                sizeof(PatternCursorAcceleration2),
                                8);
          FindUniqueBytePattern(&Address,
                                Start,
                                End,
                                PatternCursorAcceleration3,
                                sizeof(PatternCursorAcceleration3),
                                8);
          FindUniqueBytePattern(&Address,
                                Start,
                                End,
                                PatternCursorAcceleration4,
                                sizeof(PatternCursorAcceleration4),
                                9);
        #endif

        #ifdef _M_X64
          FindUniqueBytePattern(&Address,
                                Start,
                                End,
                                PatternCursorAcceleration1,
                                sizeof(PatternCursorAcceleration1),
                                8);
          FindUniqueBytePattern(&Address,
                                Start,
                                End,
                                PatternCursorAcceleration2,
                                sizeof(PatternCursorAcceleration2),
                                7);
        #endif
    }

    if (Address == (PVOID)-1)
        Address = NULL;

    return Address;
}

VOID
FASTCALL
FindUniqueBytePattern(
    __inout PVOID *Address,
    __in PUCHAR Start,
    __in PUCHAR End,
    __in PUCHAR Pattern,
    __in SIZE_T Size,
    __in_opt SIZE_T Offset
    )
/*++

Search for unique pattern in byte sequence.
Address receives the address of found pattern plus Offset,
or -1 if the pattern has been found multiple times.

The wildcard character is 0xAD.

--*/
{
    SIZE_T i;

    PAGED_CODE();

    for (End -= Size - 1; Start <= End; Start++) {
        for (i = 0; i < Size; i++) {
            if ((Pattern[i] != 0xAD) && (Start[i] != Pattern[i]))
                goto Loop;
        }

        // Abort if multiple locations have been found.
        if (*Address) {
            *Address = (PVOID)-1;
            return;
        }

        *Address = (PVOID)((ULONG_PTR)Start + Offset);

      Loop:;
    }
}

__forceinline
BOOLEAN
PatchCursorAcceleration(
    __in PUCHAR Address
    )
/*++

Disable cursor acceleration.

--*/
{
    BOOLEAN Status;
    PMDL Mdl;

    PAGED_CODE();

    // Abort if cursor acceleration is already disabled.
    if ((*Address & 0xF4) != *Address)
        return TRUE;

    Mdl = IoAllocateMdl(Address, sizeof(*Address), FALSE, FALSE, NULL);

    if (!Mdl)
        return FALSE;

    // This is well-behaved system code, so no exception handling needed.
    MmProbeAndLockPages(Mdl, KernelMode, IoModifyAccess);

    // Provide write access to read-only memory.
    Address = MmMapLockedPagesSpecifyCache(Mdl,
                                           KernelMode,
                                           MmCached,
                                           NULL,
                                           FALSE,
                                           NormalPagePriority);

    if (Address) {
        *Address ^= 7;
    }

    Status = Address != NULL;

    MmUnlockPages(Mdl);
    IoFreeMdl(Mdl);

    return Status;
}

VOID
DriverUnload(
    __in PDRIVER_OBJECT       DriverObject
    )
{
    PAGED_CODE();

    KdPrint(("[WCAFIX] Unloaded.\n"));
}