W11.xml is the actual NTLite preset.
$OEM$ goes into the Sources directory of the install media/extracted WIM folder.
RegFiles_Win11 are to be incorporated in NTLite.
autounattend.xml is required to be loaded into NTLite.
